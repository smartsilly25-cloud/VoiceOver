VoiceOver Fix - versi Windows

CARA BUILD (di GitHub):
1. Upload file ZIP INI APA ADANYA (jangan diekstrak) ke halaman utama repo GitHub.
   Nama file harus diawali "VoiceOverFix-Windows" dan berakhiran .zip.
2. Buat file workflow lewat web GitHub: Add file > Create new file, ketik nama
   .github/workflows/build.yml  lalu tempel isi YAML dari chat, lalu Commit.
3. Buka tab Actions, tunggu build selesai (±6-10 menit), lalu download artifact
   "VoiceOverFix-Windows" di bagian bawah halaman.
4. Ekstrak hasil download, buka folder VoiceOverFix, jalankan VoiceOverFix.exe.

CATATAN:
- Hasil otomatis disimpan di folder "Hasil" yang dibuat di samping VoiceOverFix.exe.
- Pertama kali "Proses", model Whisper diunduh otomatis (tiny ±75 MB, base ±142 MB,
  small ±466 MB, medium ±1,5 GB) dan disimpan di %LOCALAPPDATA%\VoiceOverFix\models.
- Pastikan folder "bin" (ffmpeg.exe + whisper-cli.exe) tetap berada di samping VoiceOverFix.exe.
- Windows SmartScreen bisa muncul karena aplikasi belum ditandatangani:
  klik "More info" > "Run anyway".
